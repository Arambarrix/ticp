package fr.istic.ticp.model;

public class Photo {
}
