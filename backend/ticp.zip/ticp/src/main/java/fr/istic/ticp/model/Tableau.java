package fr.istic.ticp.model;

import java.util.List;

public class Tableau {
    private int ID;
    private String nom;
    private List<Equipe> equipes;
    private List<Match> matchs;
}
